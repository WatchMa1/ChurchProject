<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\LoginForm */
/* @var $form ActiveForm */


?>
<hr>
<br>

Your password has been succefully changed. A confirmation email has been sent to you. Click the link below to login.

<br>
<br>