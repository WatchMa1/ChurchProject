<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="generator" content="pdf2htmlEX" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="stylesheet" href="https://sililoconnect.com/assets/img/css1.css">
    <link rel="stylesheet" href="https://sililoconnect.com/assets/img/css2.css">


    <title></title>


</head>

<body>
    <div id="sidebar">
        <div id="outline">
        </div>
    </div>
    <div id="page-container">
        <div id="pf1" class="pf w0 h0" data-page-no="1">
            <div class="pc pc1 w0 h0">
                <img class="bi x0 y0 w1 h1" alt=""
                    src="https://sililoconnect.com/assets/img/bulletin-cover.png" 
                />
                <div class="c x0 y1 w2 h0">
                    <div class="t m0 x1 h2 y2 ff1 fs0 fc0 sc0 ls2 ws3"><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x1 h2 y3 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y4 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y5 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y6 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y7 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y8 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y9 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 ya ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 yb ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 yc ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 yd ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 ye ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 yf ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y10 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y11 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y12 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y13 ff1 fs0 fc0 sc0 ls2 ws3"><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x1 h2 y14 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y15 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y16 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y17 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y18 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y19 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y1a ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y2 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y3 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y4 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y5 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y6 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y7 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y8 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y9 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 ya ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 yb ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 yc ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 yd ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 ye ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 yf ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y10 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y11 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y12 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y13 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y14 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y15 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y16 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y17 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y18 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y19 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y1a ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x3 h2 y1b ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y1c ff1 fs0 fc0 sc0 ls2 ws3"><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x4 h2 y1d ff1 fs0 fc0 sc0 ls2 ws3"><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x4 h2 y1e ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y1f ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y20 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y21 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y22 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y23 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y24 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y25 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y26 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y27 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y28 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                </div>
                <div class="c x4 y29 w3 h3">
                    <div class="t m0 x5 h4 y2a ff2 fs1 fc0 sc0 ls2 ws0"> THEME<span class="ff3 ls3 ws3">: </span></div>
                    <div class="t m1 x6 h5 y2a ff4 fs2 fc0 sc0 ls2 ws3">“The The goe<span class="_ _0"></span>s
                        here”<span class="ff3"> </span></div>
                </div>
                <div class="c x7 y2b w4 h6">
                    <div class="t m0 x8 h7 y2c ff5 fs1 fc1 sc0 ls0 ws3">24 <span class="ls2">OCT 202<span
                                class="_ _0"></span>2 <span class="_ _1"> </span> <span class="_ _2"> </span> <span
                                class="_ _2"> </span>CHURCH BULLET<span class="_ _0"></span>IN </span></div>
                </div>
                <div class="c x7 y2d w5 h8">
                    <div class="t m0 x8 h9 y2e ff6 fs3 fc0 sc0 ls2 ws3">Welcome <span class="_ _3"> </span>to <span
                            class="_ _4"> </span>Universi<span class="_ _5"></span>ty <span class="_ _4">
                        </span>Seventh<span class="_ _5"></span>-day <span class="_ _3"> </span>Adventist<span
                            class="_ _5"></span><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x8 h9 y2f ff6 fs3 fc0 sc0 ls2 ws3">Church. <span class="_ _6"></span>We <span
                            class="_ _6"></span>invoke <span class="_ _6"></span>rich <span class="_ _6"> </span>bl<span
                            class="_ _5"></span>essings <span class="_ _6"></span>upon <span class="_ _6"></span>you
                        <span class="_ _6"></span>f<span class="_ _5"></span>rom<span class="fc3 sc0"> </span>
                    </div>
                    <div class="t m0 x8 h9 y30 ff6 fs3 fc0 sc0 ls2 ws3">our <span class="_ _7"></span>f<span
                            class="_ _5"></span>ather <span class="_ _7"></span>i<span class="_ _5"></span>n <span
                            class="_ _7"></span>he<span class="_ _5"></span>aven. <span class="_ _7"></span>Spe<span
                            class="_ _5"></span>cial <span class="_ _0"></span>thanks <span class="_ _7"></span>and<span
                            class="_ _5"></span> w<span class="_ _7"></span>elcom<span class="_ _5"></span>e<span
                            class="fc3 sc0"> </span></div>
                    <div class="t m0 x8 h9 y31 ff6 fs3 fc0 sc0 ls2 ws3">go <span class="_ _8"> </span>to <span
                            class="_ _8"> </span>all <span class="_ _8"> </span>Visitors <span class="_ _8">
                        </span>joining <span class="_ _8"> </span>us <span class="_ _8"> </span>in <span class="_ _8">
                        </span>Worship <span class="_ _8"> </span>this<span class="fc3 sc0"> </span></div>
                    <div class="t m0 x8 h9 y32 ff6 fs3 fc0 sc0 ls2 ws3">Sabbath. <span class="_"> </span>Please <span
                            class="_"> </span>be <span class="_"> </span>at<span class="_ _0"></span> <span class="_">
                        </span>home <span class="_"> </span>as <span class="_"> </span>w<span class="_ _7"></span>e<span
                            class="_ _5"></span> <span class="_"> </span>fello<span class="_ _5"></span>w<span
                            class="_ _0"></span>ship<span class="fc3 sc0"> </span></div>
                    <div class="t m0 x8 h9 y33 ff6 fs3 fc0 sc0 ls2 ws3">together <span class="_ _9"> </span>and <span
                            class="_ _9"> </span>do <span class="_ _9"> </span>come <span class="_ _9"> </span>again.
                        <span class="_ _9"> </span>Our <span class="_ _9"> </span>mission <span class="_ _9"> </span>is
                        <span class="_ _9"> </span>the<span class="fc3 sc0"> </span>
                    </div>
                    <div class="t m0 x8 h9 y34 ff6 fs3 fc0 sc0 ls2 ws3">Proclamation <span class="_ _a"> </span>of <span
                            class="_ _a"> </span>the <span class="_ _a"> </span>everla<span class="_ _0"></span>sting
                        <span class="_ _a"> </span>Gospel <span class="_ _a"> </span>of <span class="_ _a">
                        </span>Jesus<span class="fc3 sc0"> </span>
                    </div>
                    <div class="t m0 x8 h9 y35 ff6 fs3 fc0 sc0 ls2 ws3">Christ <span class="_ _5"></span>i<span
                            class="_ _5"></span>n <span class="_ _b"></span>and <span class="_ _b"></span>around <span
                            class="_ _5"></span>ou<span class="_ _5"></span>r <span class="_ _b"></span>territorial
                        <span class="_ _b"></span>neighborhood<span class="_ _5"></span><span class="fc3 sc0"> </span>
                    </div>
                    <div class="t m0 x8 h9 y36 ff6 fs3 fc0 sc0 ls2 ws3">through <span class="_ _c"> </span>Evangelism,
                        <span class="_"> </span>Nurture <span class="_ _c"> </span>and <span class="_ _d">
                        </span>Stewardship.<span class="_ _5"></span><span class="fc3 sc0"> </span>
                    </div>
                    <div class="t m0 x8 h9 y37 ff6 fs3 fc0 sc0 ls2 ws3">May <span class="_ _a"> </span>Go<span
                            class="_ _5"></span>d <span class="_ _a"> </span>bl<span class="_ _5"></span>ess <span
                            class="_ _d"> </span>you <span class="_ _d"> </span>as <span class="_ _a"> </span>we <span
                            class="_ _d"> </span>w<span class="_ _0"></span>orsh<span class="_ _5"></span>ip <span
                            class="_ _d"> </span>together <span class="_ _a"> </span>i<span class="_ _5"></span>n<span
                            class="fc3 sc0"> </span></div>
                    <div class="t m0 x8 h9 y38 ff6 fs3 fc0 sc0 ls2 ws3">Spirit and Truth!<span class="_ _5"></span>
                    </div>
                </div>
                <div class="c x9 y39 w6 ha">
                    <div class="t m0 xa hb y3a ff7 fs3 fc2 sc0 ls2 ws1">www.unisdac.org<span class="_ _5"></span><span
                            class="fc0 ws3"> </span></div>
                    <div class="t m0 xb hb y3b ff7 fs3 fc2 sc0 ls2 ws1">info@universitysdachu<span
                            class="_ _5"></span>rch.org<span class="fc0 ws3"> </span></div>
                    <div class="t m0 xc hb y3c ff7 fs3 fc2 sc0 ls2 ws1">https://www.facebook.co<span
                            class="_ _5"></span>m/universityad<span class="_ _5"></span>ventist/live<span
                            class="_ _5"></span><span class="fc0 ws3"> </span></div>
                    <div class="t m0 xb hb y3d ff7 fs3 fc2 sc0 ls2 ws1">http://www.mixlr.co<span
                            class="_ _5"></span>m/unisda<span class="_ _5"></span><span class="fc0 ws3"> </span></div>
                    <div class="t m0 xd hb y3e ff7 fs3 fc2 sc0 ls2 ws1">https://www.youtube.co<span
                            class="_ _5"></span>m/chann<span class="_ _5"></span>el/UCBLrsGsp94BsLV</div>
                    <div class="t m0 xe hc y3f ff7 fs3 fc2 sc0 ls2 ws1">UxGZV7OfQ<span class="fs1 fc0 ws3"> </span>
                    </div>
                </div>
                <div class="c xf y40 w7 h6">
                    <div class="t m0 x10 h7 y2c ff5 fs1 fc1 sc0 ls2 ws3">CHURCH CONTA<span class="_ _0"></span>CTS
                    </div>
                </div>
                <div class="c x11 y41 w8 hd">
                    <div class="t m0 x8 hc y42 ff7 fs1 fc0 sc0 ls2 ws3">here weren&apos;t sup<span
                            class="_ _0"></span>posed to be drag<span class="_ _0"></span>ons flying in the </div>
                    <div class="t m0 x8 hc y43 ff7 fs1 fc0 sc0 ls2 ws3">sky. First and fore<span
                            class="_ _0"></span>most, drag<span class="_ _0"></span>ons didn&apos;t exist. The<span
                            class="_ _0"></span>y </div>
                    <div class="t m0 x8 hc y44 ff7 fs1 fc0 sc0 ls2 ws3">were mythical crea<span
                            class="_ _0"></span>tures from fantas<span class="_ _0"></span>y books like </div>
                    <div class="t m0 x8 hc y45 ff7 fs1 fc0 sc0 ls2 ws3">unicorns. This was s<span
                            class="_ _0"></span>omething that P<span class="_ _0"></span>ete knew in </div>
                    <div class="t m0 x8 hc y46 ff7 fs1 fc0 sc0 ls2 ws3">his heart to be true<span class="_ _0"></span>
                        so he was having<span class="_ _0"></span> a difficult </div>
                    <div class="t m0 x8 hc y47 ff7 fs1 fc0 sc0 ls2 ws3">time acknowledg<span class="_ _0"></span>ing
                        that there <span class="_ _0"></span>were actually fire-</div>
                    <div class="t m0 x8 hc y48 ff7 fs1 fc0 sc0 ls2 ws3">breathing dragons fl<span
                            class="_ _0"></span>ying in the sk<span class="_ _0"></span>y above him.h<span
                            class="_ _0"></span>ere </div>
                    <div class="t m0 x8 hc y49 ff7 fs1 fc0 sc0 ls2 ws3">weren&apos;t supposed <span
                            class="_ _0"></span>to be dragons flying<span class="_ _0"></span> in the sky. </div>
                    <div class="t m0 x8 hc y4a ff7 fs1 fc0 sc0 ls2 ws3">First and fore<span class="_ _0"></span>most,
                        dragons did<span class="_ _0"></span>n&apos;t exist. They were </div>
                    <div class="t m0 x8 hc y4b ff7 fs1 fc0 sc0 ls2 ws3">mythical creatures<span class="_ _0"></span>
                        from fa<span class="_ _0"></span>ntasy books like </div>
                    <div class="t m0 x8 hc y4c ff7 fs1 fc0 sc0 ls2 ws3">unicorns. This was s<span
                            class="_ _0"></span>omething that Pete<span class="_ _0"></span> knew in </div>
                    <div class="t m0 x8 hc y4d ff7 fs1 fc0 sc0 ls2 ws3">his heart to be true<span class="_ _0"></span>
                        so he was having<span class="_ _0"></span> a difficult </div>
                    <div class="t m0 x8 hc y4e ff7 fs1 fc0 sc0 ls2 ws3">time acknowledg<span class="_ _0"></span>ing
                        that there <span class="_ _0"></span>were actuall<span class="_ _0"></span>y fire-</div>
                    <div class="t m0 x8 hc y4f ff7 fs1 fc0 sc0 ls2 ws3">breathing dragons fl<span
                            class="_ _0"></span>ying in the sk<span class="_ _0"></span>y above him.h<span
                            class="_ _0"></span>ere </div>
                    <div class="t m0 x8 hc y50 ff7 fs1 fc0 sc0 ls2 ws3">weren&apos;t supposed <span
                            class="_ _0"></span>to be dragons flying<span class="_ _0"></span> in the sky. </div>
                    <div class="t m0 x8 hc y51 ff7 fs1 fc0 sc0 ls2 ws3">First and fore<span class="_ _0"></span>most,
                        dragons did<span class="_ _0"></span>n&apos;t exist. They were </div>
                    <div class="t m0 x8 hc y52 ff7 fs1 fc0 sc0 ls2 ws3">mythical creatures<span class="_ _0"></span>
                        from fa<span class="_ _0"></span>ntasy books like </div>
                    <div class="t m0 x8 hc y53 ff7 fs1 fc0 sc0 ls2 ws3">unicorns. This was s<span
                            class="_ _0"></span>omething that P<span class="_ _0"></span>ete knew in </div>
                    <div class="t m0 x8 hc y54 ff7 fs1 fc0 sc0 ls2 ws3">his heart to be true<span class="_ _0"></span>
                        so he was having<span class="_ _0"></span> a difficult </div>
                    <div class="t m0 x8 hc y55 ff7 fs1 fc0 sc0 ls2 ws3">time acknowledg<span class="_ _0"></span>ing
                        that there <span class="_ _0"></span>were actuall<span class="_ _0"></span>y fire-</div>
                    <div class="t m0 x8 hc y56 ff7 fs1 fc0 sc0 ls2 ws3">breathing dragons fl<span
                            class="_ _0"></span>ying in the sk<span class="_ _0"></span>y above him.h<span
                            class="_ _0"></span>ere </div>
                    <div class="t m0 x8 hc y57 ff7 fs1 fc0 sc0 ls2 ws3">weren&apos;t supposed <span
                            class="_ _0"></span>to be dragons flying<span class="_ _0"></span> in the sky. </div>
                    <div class="t m0 x8 hc y58 ff7 fs1 fc0 sc0 ls2 ws3">First and fore<span class="_ _0"></span>most,
                        dragons did<span class="_ _0"></span>n&apos;t exist. They were </div>
                    <div class="t m0 x8 hc y59 ff7 fs1 fc0 sc0 ls2 ws3">mythical creatures<span class="_ _0"></span>
                        from fa<span class="_ _0"></span>ntasy books like </div>
                    <div class="t m0 x8 hc y5a ff7 fs1 fc0 sc0 ls2 ws3">unicorns. This was s<span
                            class="_ _0"></span>omething that P<span class="_ _0"></span>ete knew in </div>
                    <div class="t m0 x8 hc y5b ff7 fs1 fc0 sc0 ls2 ws3">his heart to be true<span class="_ _0"></span>
                        so he was having<span class="_ _0"></span> a difficult </div>
                    <div class="t m0 x8 hc y5c ff7 fs1 fc0 sc0 ls2 ws3">time acknowledg<span class="_ _0"></span>ing
                        that there <span class="_ _0"></span>were actually fire-</div>
                    <div class="t m0 x8 hc y5d ff7 fs1 fc0 sc0 ls2 ws3">breathing dragons fl<span
                            class="_ _0"></span>ying in the sk<span class="_ _0"></span>y above him.h<span
                            class="_ _0"></span>ere </div>
                    <div class="t m0 x8 hc y5e ff7 fs1 fc0 sc0 ls2 ws3">weren&apos;t supposed <span
                            class="_ _0"></span>to be dragons flying<span class="_ _0"></span> in the sky. </div>
                    <div class="t m0 x8 hc y5f ff7 fs1 fc0 sc0 ls2 ws3">First and fore<span class="_ _0"></span>most,
                        dragons did<span class="_ _0"></span>n&apos;t exist. They were </div>
                    <div class="t m0 x8 hc y60 ff7 fs1 fc0 sc0 ls2 ws3">mythical creatures<span class="_ _0"></span>
                        from fa<span class="_ _0"></span>ntasy books like </div>
                    <div class="t m0 x8 hc y61 ff7 fs1 fc0 sc0 ls2 ws3">unicorns. This was s<span
                            class="_ _0"></span>omething that P<span class="_ _0"></span>ete knew in </div>
                    <div class="t m0 x8 hc y62 ff7 fs1 fc0 sc0 ls2 ws3">his heart to be true<span class="_ _0"></span>
                        so he was having<span class="_ _0"></span> a difficult </div>
                    <div class="t m0 x8 hc y63 ff7 fs1 fc0 sc0 ls2 ws3">time acknowledg<span class="_ _0"></span>ing
                        that there <span class="_ _0"></span>were a in the sk<span class="_ _0"></span>y. </div>
                    <div class="t m0 x8 hc y64 ff7 fs1 fc0 sc0 ls2 ws3">First and fore<span class="_ _0"></span>most,
                        dragons did<span class="_ _0"></span>n&apos;t exist. They were </div>
                    <div class="t m0 x8 hc y65 ff7 fs1 fc0 sc0 ls2 ws3">mythical creatures<span class="_ _0"></span>
                        from fa<span class="_ _0"></span>ntasy books like </div>
                    <div class="t m0 x8 hc y66 ff7 fs1 fc0 sc0 ls2 ws3">unicorns. This was s<span
                            class="_ _0"></span>omething that P<span class="_ _0"></span>ete knew in </div>
                    <div class="t m0 x8 hc y67 ff7 fs1 fc0 sc0 ls2 ws3">his heart to be true<span class="_ _0"></span>
                        so he was having<span class="_ _0"></span> a difficult </div>
                    <div class="t m0 x8 hc y68 ff7 fs1 fc0 sc0 ls2 ws3">time acknowledg<span class="_ _0"></span>ing
                        that there <span class="_ _0"></span>were actuall<span class="_ _0"></span>y fire-</div>
                    <div class="t m0 x8 hc y69 ff7 fs1 fc0 sc0 ls2 ws3">breathing dragons fl<span
                            class="_ _0"></span>ying in the sk<span class="_ _0"></span>y above him. </div>
                </div>
                <div class="c x12 y6a w9 h6">
                    <div class="t m0 xb h7 y2c ff5 fs1 fc1 sc0 ls2 ws3">PRINCIPLES OF OUR<span class="_ _0"></span>
                        FAITH </div>
                </div>
                <div class="c x1 y6b wa he">
                    <div class="t m0 x8 h9 y6c ff8 fs3 fc0 sc0 ls4 ws3">• <span class="ff9 fs4 ls2">God our Creator.
                        </span></div>
                    <div class="t m0 x8 hf y6d ff8 fs4 fc0 sc0 ls2 ws3">• Jesus Christ our Saviour.  </div>
                    <div class="t m0 x8 hf y6e ff8 fs4 fc0 sc0 ls2 ws3">• The Holy Spirit our Comforter.  </div>
                    <div class="t m0 x8 hf y6f ff8 fs4 fc0 sc0 ls2 ws3">• The regeneration and the new birth through the 
                        acceptance of God. </div>
                    <div class="t m0 x8 hf y71 ff8 fs4 fc0 sc0 ls2 ws3">• The Bible – the inspired Word of God 
                        –our Guide. </div>
                    <div class="t m0 x8 hf y73 ff8 fs4 fc0 sc0 ls2 ws3">• The literal, personal, and imminent return of Christ. </div>
                    <div class="t m0 x8 hf y74 ff8 fs4 fc0 sc0 ls2 ws3">• The Ten Commandments and the example of Jesus as our standard of conduct. </div>
                    <div class="t m0 x8 hf y76 ff8 fs4 fc0 sc0 ls2 ws3">• The seventh day of the week as God’s Sabbath, from sunset Friday until sunset Saturday. </div>
                    <div class="t m0 x8 hf y77 ff8 fs4 fc0 sc0 ls2 ws3">• The gifts of the Holy Spirit to the Church.</div>
                    <div class="t m0 x8 hf y78 ff8 fs4 fc0 sc0 ls2 ws3">• Healthful living, remembering that our bodies 
                    are the temples of the Holy Ghost. </div>
                    <div class="t m0 x8 hf y7a ff8 fs4 fc0 sc0 ls2 ws3">• The mortality of man and resurrection of the saved to eternal life at Christ’s return.  </div>
                    <div class="t m0 x8 hf y7c ff8 fs4 fc0 sc0 ls2 ws3">• The ultimate final destruction of sin and the wicked. </div>
                    <div class="t m0 x8 hf y7e ff8 fs4 fc0 sc0 ls2 ws3">• Baptism by immersion.
                        </div>
                    <div class="t m0 x8 hf y7f ff8 fs4 fc0 sc0 ls2 ws3">• Observing the ordinance of Humility and the  Lord’s Supper. </div>
                    <div class="t m0 x8 hf y81 ff8 fs4 fc0 sc0 ls2 ws3">• The return of one-tenth of
                            our income to the  Lord. </div>
                    <div class="t m0 x8 hf y83 ff8 fs4 fc0 sc0 ls2 ws3">• Support of the Gospel by willing missionary
                     service and gifts as the Lord prospers us.
                    </div>
                    <div class="t m0 x8 hf y85 ff8 fs4 fc0 sc0 ls2 ws3">• Avoiding worldliness in our deportment, recreation, attire, conversation and social relationship. </div>
                    <div class="t m0 x8 hf y88 ff8 fs4 fc0 sc0 ls2 ws3">• Justification by faith through Jesus.  ></div>
                    <div class="t m0 x8 hf y89 ff8 fs4 fc0 sc0 ls2 ws3">• Loyalty to the church and its organization, refraining from any word or deed that might tarnish its fair name. </div>
                </div>
                <div class="c x1 y8c wb h10">
                    <div class="t m0 x8 h11 y8d ffa fs4 fc0 sc0 ls2 ws3">If you know of people who ask questions about
                        our faith </div>
                    <div class="t m0 x8 h11 y8e ffa fs4 fc0 sc0 ls2 ws3">and would be willing to have s<span
                            class="_ _0"></span>omebody from our Church </div>
                    <div class="t m0 x8 h11 y8f ffa fs4 fc0 sc0 ls2 ws3">discuss these questions with them? Ple<span
                            class="_ _0"></span>ase give their </div>
                    <div class="t m0 x8 h11 y90 ffa fs4 fc0 sc0 ls2 ws3">contact details to the INTEREST COORD<span
                            class="_ _0"></span>INATOR,<span class="_ _5"></span> </div>
                    <div class="t m0 x8 h11 y91 ffa fs4 fc0 sc0 ls2 ws3">If you know of someone who is ill, wishes to
                        enquire into </div>
                    <div class="t m0 x8 h11 y92 ffa fs4 fc0 sc0 ls2 ws3">Adventist beliefs &amp; practices, wishes to
                        join the baptism<span class="_ _0"></span> </div>
                    <div class="t m0 x8 h11 y93 ffa fs4 fc0 sc0 ls2 ws3">class, has a useful suggestion, PLEASE LET THE
                        ELDERS </div>
                    <div class="t m0 x8 h11 y94 ffa fs4 fc0 sc0 ls2 ws3">KNOW. If you desire to transfer membership,
                        CONTACT </div>
                    <div class="t m0 x8 h11 y95 ffa fs4 fc0 sc0 ls2 ws3">THE CLERKS. OR, in the space below, s<span
                            class="_ _0"></span>ign, detach and place </div>
                    <div class="t m0 x8 h11 y96 ffa fs4 fc0 sc0 ls2 ws3">in the offering bag. </div>
                    <div class="t m0 x8 h11 y97 ffa fs4 fc0 sc0 ls2 ws3">NAME:
                        ___________________________________________ </div>
                    <div class="t m0 x8 h11 y98 ffa fs4 fc0 sc0 ls2 ws3">ADDRESS:
                        ________________________________________ </div>
                    <div class="t m0 x8 h11 y99 ffa fs4 fc0 sc0 ls2 ws3">PHONE:
                        __________________________________________ </div>
                    <div class="t m0 x8 h11 y9a ffa fs4 fc0 sc0 ls2 ws3">EMAIL:
                        ___________________________________________ </div>
                    <div class="t m0 x13 h11 y9b ffa fs4 fc0 sc0 ls2 ws3">Select the most appropriate option(s) below:
                    </div>
                    <div class="t m0 x8 h12 y9c ffb fs4 fc0 sc1 ls5 ws2">__<span class="ls2 ws3">Pra<span
                                class="_ _0"></span>yer <span class="_"> </span> <span class="_ _e"> </span>__Ba<span
                                class="_ _0"></span>pti<span class="_ _0"></span>sm <span class="_ _f">
                            </span>__Bel<span class="_ _0"></span>ief<span class="_ _0"></span>s/Bibl<span
                                class="_ _0"></span>e st<span class="_ _0"></span>udy<span class="_ _0"></span> </span>
                    </div>
                    <div class="t m0 x8 h12 y9d ffb fs4 fc0 sc1 ls2 ws3">__Visi<span class="_ _0"></span>tati<span
                            class="_ _0"></span>on<span class="_ _0"></span> <span class="_ _10"> </span>__Su<span
                            class="_ _0"></span>ggest<span class="_ _0"></span>ion<span class="_ _0"></span> <span
                            class="_ _11"> </span>__M<span class="_ _0"></span>emb<span class="_ _0"></span>ershi<span
                            class="_ _0"></span>p T<span class="_ _0"></span>ran<span class="_ _0"></span>sfer<span
                            class="_ _0"></span> </div>
                </div>
                <div class="c x12 y9e wc h13">
                    <div class="t m0 x14 h7 y9f ff5 fs1 fc1 sc0 ls2 ws3">INTEREST &amp; RES<span
                            class="_ _0"></span>PONSE </div>
                </div><a class="l" href="http://www.unisdac.org/">
                    <div class="d m2"
                        style="border-style:none;position:absolute;left:619.850000px;bottom:99.427000px;width:75.450000px;height:13.173000px;background-color:rgba(255,255,255,0.000001);">
                    </div>
                </a><a class="l" href="mailto:info@universitysdachurch.org">
                    <div class="d m2"
                        style="border-style:none;position:absolute;left:594.160000px;bottom:86.253000px;width:126.830000px;height:13.174000px;background-color:rgba(255,255,255,0.000001);">
                    </div>
                </a><a class="l" href="https://www.facebook.com/universityadventist/live">
                    <div class="d m2"
                        style="border-style:none;position:absolute;left:549.190000px;bottom:73.080000px;width:216.770000px;height:13.173000px;background-color:rgba(255,255,255,0.000001);">
                    </div>
                </a><a class="l" href="http://www.mixlr.com/unisda">
                    <div class="d m2"
                        style="border-style:none;position:absolute;left:594.020000px;bottom:59.907000px;width:127.110000px;height:13.173000px;background-color:rgba(255,255,255,0.000001);">
                    </div>
                </a><a class="l" href="https://www.youtube.com/channel/UCBLrsGsp94BsLVUxGZV7OfQ">
                    <div class="d m2"
                        style="border-style:none;position:absolute;left:540.900000px;bottom:46.733000px;width:233.350000px;height:13.174000px;background-color:rgba(255,255,255,0.000001);">
                    </div>
                </a><a class="l" href="https://www.youtube.com/channel/UCBLrsGsp94BsLVUxGZV7OfQ">
                    <div class="d m2"
                        style="border-style:none;position:absolute;left:540.900000px;bottom:33.560000px;width:143.370000px;height:13.173000px;background-color:rgba(255,255,255,0.000001);">
                    </div>
                </a>
            </div>
            <div class="pi" data-data='{"ctm":[1.000000,0.000000,0.000000,1.000000,0.000000,0.000000]}'></div>
        </div>
        <div id="pf2" class="pf w0 h0" data-page-no="2">
            <div class="pc pc2 w0 h0"><img class="bi x0 y0 w1 h1" alt=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABjEAAATJCAIAAAAZxaNvAAAACXBIWXMAABYlAAAWJQFJUiTwAAAgAElEQVR42uzdf4zfdWHH8fddv9c72sK12CvF9FgxKzRMLttqhNUw6SJswY2akSyjxoSYEPmrE4V/tsyNqCRGtilLFomZMUHAkJgIijPVyAixWiKGtIa0YqChF2y549qj7fV+fO/73R+f7FKrc8Tvt69+7svj8df37o937t6f5PO+9/Pz4/ra7XYBAAAAgKB+UwAAAABAmCYFAAAAQJomBQAAAECaJgUAAABAmiYFAAAAQJomBQAAAECaJgUAAABAmiYFAAAAQJomBQAAAECaJgUAAABAmiYFAAAAQJomBQAAAECaJgUAAABAmiYFAAAAQFrDFAAAALV1embu5SMTBw6Of/sHL5gNgAti+7Ytf3TNFVe9a+PIpRd3cdi+drttcgEAgLppNluf/OzXH/zq90wFQE2MbR194su7N29a35XR6tikDhwaf2bfob3Pv/TYk/scb4DltUTdeP3WP//Td998w7sbjcTj4adn5iamTpp5gLzVqwa7e7X81zcFN3/kgaMT09WXQ2tWDq5eObDScx4AaYuLrbmZ+ZkTs0vfeeQLH9u18/rOR65Xk3IlBKA3jG0d/f4j956nvUqz2drz7M++9s29T//o4NJeBYAL4vZbr9u+bctdu3Z091LEgUPjY3/xj9Xn9aNrV6+7yFQDXHDN+ebrh48vzDZLKbvvuOmL/7SrwwFr1KQOj0/+yV9/ptpdDAw1hkfWDAw1+lf0OeoAy8Xc6YW5mfmTb8xUX3br+sk5i8XOOx/cf/CI2Qaoj40jw3sevufaqzd1Z8/TbI1u/8TRiemhNSvXX7F2RWOFGQaoiXa7Pf36qeljp0op+7/76Q7P/HVpUksLT3ElBGCZO/v6SecL1dkefeLHH/74Q9Xn4cvWDF40MDDUaHiOA+BCWGwuLswtzp9ZOP7am9V37rv7Q5/avbPzkf/uvkerJyc2XbNBkAKooWMvvzF7an7jyPCRvf/ayX2ydWlSFh6AXtJut19/ZaorC9WSw+OTV95wbyllYKixYfM6KQqgJhabi5Ovnpg9NV+6cSni9Mzcmj+4q7hQDVDvM//4i6+XUp76yt237Bj7ncfpr8Mvc+DQeBWk1o+6NRegF/T19a2/Ym0p5ejE9P3/8a3OB2w2WzvvfLCUMjDUuHzLekEKoD5WNFZc9q53rFo7VEq5+SMPnJ6Z62S0l49MVB8EKYA6n/mr0/5PDrzSyTi1aFLP7DtUbTMsPAC9tFCtH11bSvnGfz3f+WhfevTp6h1SGzav6+vzqkGA2nnHpuH+Rv/Riem///w3OhnnwMHxUsrQmpWmFKDOVl08VEp59rmfdzJILZrU3udfKqUMj6xxUAF6yeDqgVLK/oNHms1Wh0M9seenpZR177zEHVIA9dTf33/p5ZeUUh5/6rlOxvn2D14opQyu1qQAam1gqFFK+f4PX+xo7ajDb/LYk/uWfh8AesZSPxo/OtXhUNVqN2SLAlBj1aWIoxPTHT6+V0oZcAUCoN76V3Th2YX+Hvt9AKiV6uGLvc//opNBDo9PVh8ag945CFBfS5cilt4JBQC/Rb8pAOA8LjONbi40/f2WLYBaqy5FVO+EAoD/5897UwAAAHRnd9GwvwDgLa8apgAAAACAME0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAqJeF+aZJAKiz1mK780E0KQDO51rVbJkEAN66v/yzPyylzJ2eNxUAdbYw2yylfOB913QySI2aVFcaGwC1MntqvpRy7dZNpgLg7aDzSxHVklEtHwDU1szJ2VLKDe+9qpNBatGkqq5WNTYAekbzf5+8eNfoSHe2Oi13XQHUWueXIpaWjNPHz5hPgHpabC7OnJgtpbzn2is7GacWTarqaqeOzziuAL2kutiwcWR49arBTsbZvGl99aE5t2hWAWqrK5ciVq8a3H3HTaWUySMnFptO+wB1NPnqierv/JtveHcn49SiSVVdbfbU/PyZBYcWoDe0Wq3J8elSyt988L2dj1bdUTvr9SIANTZ3eqF041LEv/zD324cGa72PLIUQK202+0Tx05Wd8XuefieRqOjrFSLJnXLjrFqs3Hslal221ulAHrBG+PTrWZr48jw/ffe1vloO2/+41LK8dfebPpPTAC11Gq1pn75ZunGpYhGo3/Pw/eUUmZPzY+/+LqH+ABqojnf/OVLk9PHTpVSdt9x07VXd/rS2L6aNKCJqZMbtu0upQwMNTZsXtdY2XCwAZbvtuSN8enqCfOnvnL3LTvGurD+NVvb/uqf9x88MjDUuHzL+r6+PvMMUCsTrx6fOTG7cWT4F//9uQ7vk6ocODR+80ceODoxXX05tGbl4OqVA7YJAHGLi625mfnqz/vKI1/42K6d13c+ci2alK0FQG/rylpzeHzyyhvuLa5eANRtr9JcnHz1RPUcx/7vfrrzy+ZLms3WJz/79Qe/+j2TDFATY1tHn/jy7qX3vXZIkwLgvOvWWvPoEz/+8Mcfqj4PX7Zm8KKBgaGGOAVwQSw2FxfmFufPLBx/7c3qO/fd/aFP7d5pgwDgD/63eravT5OqfpJms/X4U899+wcvPPbkPgcVYNkZ2zp64/Vb77/3turBjbPP8F1xeHxy550P7j94xFQD1MfGkeE9D9/TxTukNCmA5aVHmtTZJqZOnp6Zc2gBlotNGy89519vdL1JlVKazdaeZ3/2tW/uffpHB5feMwLABXH7rddt37blrl07OvzXS29xgwBA3XRyxq51kwLg7bxEvRWnZ+Ympk6aZ4C81asGRy692AYBwB/8v/MZ2zs4AFiuKx8Ay4K0BMBv1G8KAAAAAAhznxQAy5UL7wA157ZWAH4L90kBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQpkkBAAAAkKZJAQAAAJCmSQEAAACQ1qjPj9LX1+d4AAAAALwduE8KAAAAgLRa3CfVbreXPjebrS89+vQTe376/R++6PAALDtjW0dvvH7r/ffetnrVoNkAAAD+L31n96AL7vD45M47H9x/8IgDA7CsbRwZ/s/PffSWHWPna/Xq6yu/ekkDgDpuNn7X07XzPEDPn+pLrZrUd57e/8GP/lv1efiyNasuGWoMrujv93QhwLLRnG8uzDYnx6dbzVYp5fZbr3v0i3fVbeUDoP4bFed5gJ4/1Zf6NKmJqZMbtu0upQwMNTZsXtdY2XBcAZapdrs9eeTEzInZUsojX/jYrp3X12rlA6D+GxXneYCeP9WX+rzjfNfuL5VS+hv9l29ZL0gBLPdlaeSKdRe/Y1Up5cMff2hi6qQ5AQAAzlGLJvWdp/dXbzS/7MpLq8AGwHK37p2X9Df6Symf+fdvmQ0AAOActWhSPznwSill1dqhlRcNOCQAvaGvr2/k99aVUh5/6jmzAQAAnKMWTerZ535eSll18ZDjAdBLBgZXlFKOTkyfnpkzGwAAwNlq0aSqB/cGV7tJCqCnrGisqD68fGTCbAAAAGfrNwUAnD+r1g6VUg4cHDcVAADA2TQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAAAAA0jQpAAAAANI0KQAAAADSNCkAzqOF2aZJAAAAfl2NmlRzoeV4APSSdrtdNant237fbAAAAGerRZO6/dbrSinzZxYcD4BesriwWH3YtPFSswEAAJytFk1q+7YtpZRTUzOOB0AvmXlzrpQytnW00fCoOAAA8CtqsUl4/3VXl1IWZpunj59xSAB6w2Jz8fhrb5ZS7rz9/WYDAAA4Ry2a1LVXb9p9x02llMkjJxabi44KwHLXbrePvTxVShnbOnrXrh0mBAAAOEdfu92uw8/RbLZGt3/i6MR0KWX96NrV6y5ybACWqfkzC8demWo1W6WUV579/OZN67u/evX1lVJqsoQB0PXTtfM8QM+f6ktNmlT1CwDQq7q+1tirAPT2RsV5HqDnT/WlJs/uAQAAAPC20qjPj7IU1Q4cGn9m36G9z7/02JP7HCGAZeQD77vmhvde9Z5rr7xlx1j1HXfCAgAAv1GNnt1zay5ADy4z5+cMb+EA6O1VwHke4O3wB79n9wAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpP6nvXuLkas+7Dj+n93xer2+X9bdwNpYKIBjCSuIVqTmJbRxVAVEHhMcKiGqCNSqJiS9qIqqBFVRhNIUcCVEFBHxEJyo6gspVI2MAi+hUAkVYRWZYlEaO8aKL2t2vVePZ/pwyDalqdQde38+M3w+L95BPv8x/5HOnPM9/3MWAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACANE0KAAAAgDRNCgAAAIA0TQoAAACAtKYpAKBHNRoNkwAAAD3KOikAAAAA0qyTAqD3dDodkwDQ96yHBehv1kkBAAAAkGadFAAAUC/WwwJ8GNSoSVmaCwAAAPAhYZ0UAD1vemb+7WOnDh85/uxPXjMbAFfKnpuvu2nX9o/v2r56ZOUy7e1fe+Nn//rGz1569S2zDQmnDMYAABKNSURBVHCl3PE7H79x5/i120YvfW/fsCwWgJ528JmXv/Cl75gHgPr424fuvn/fbc3mZXt2bavVfuLgC3/8te+bW4D6ePrR+/Z99hOXMoImBUCvOnV2at/+J57/6RvVy+E1QytXD60YsgQY4Aq4eLE9P7Mwc26uerl757Znvrt/x/iWSx/5neOnP/vFA68fOVa9HNkwvHJkaHDQL2sCuAIuLLTmpxfmzi9ULz91666DB+4f3bS2u9Fq2qRarfbxk2dfevWozxugh1xz9ebrrx3r+jtpqd8U2/Z8+eSp90opazePbLxqnecSAlxxnU5n6szMxInJUsrY6PqjLz58iXd2TM/Mf/STf17t7TdetW7t5hF7e4A67O0nTkxOnZmp9vbHXvqb7tbG1q5JfeCiNwA9Z2x0/d8//ke3/uZ1y/ouDzx08MBTh0opH7luy9CqFaYdoD5aC613j55pt9p33XnLwcfuv5Sh9j3wxA9+9MpAc+AjH93ctBIWoE4WZi+8+9bpUsr+e/Y+9rV9XYxQryb1gWeCDK8ZGmhalAvQMxZv2ai+mb791c83l2c3fvjN47t/7y9LKVu2bVi9cZWZB6ib2cm5X7wzUUp57nsPfua23d0N8o8vvH77vY+UUrbu2Lhq3bBZBaib6YnZ08fOlVJe/6e/uvGG8aVuXqNLDYtXvAeaA6PXbBxePeTTBegx28vF1sWzJyZnzs0deOrQiy8fefUfvr4cWeqbjz9bShleMyRIAdTTqnXDIxuGZ87NPfLkj7tuUo88+eNSysiGYUEKoJ5Wb1x1fmJm7vzCNx9/touFsXVZhXT4zeNVkFq7eWT8Y1sFKYAeNdgcHN2+ceuOjaWU148c+8o3frgc7/LCPx8ppazbstqEA9TW+tE1pZRLeShHtW01DgD1VB2TV8fnS1WLJtVqtT/9+39dShleM7Tp6vUeWwjQ61atG96ybUMp5cBThw6/efzyDj49M1897HbFsAeLANRXc+Vg9cM7x093sfniVovjAFBD1TH5yVPvTc/ML3XbWjSpv3vuX6qziy3bN/g4AfrD6o2rhtcMlV/eZ3cZnTo79f5ZiofdAtTYwMBA9XDYN9460cXm1VYDzYGBAU+YBaivxWPyxaP0JXxT1OF/4JXX3i6lrN08Mth0DQSgf6z/jbWllB/86BVTAfDhVF2cODc508W21VbVCAD0pVo0qRdfPlJKWbV2pc8DoJ8Mrer+mgkAANDfatGkXj9yrHgsCED/fcf88q6Nf3/7pNkAAAD+x/mCKQBg+VT3XPznz8+YCgAA4FdpUgAAAACkaVIAAAAApGlSAAAAAKRpUgAAAACkaVIAAAAApGlSAAAAAKRpUgAAAACkaVIAAAAApGlSAAAAAKRpUgAAAACkaVIAAAAApGlSAAAAAKRpUgAAAACkaVIAAAAApGlSAAAAAKRpUgAAAACkaVIAAAAApGlSAAAAAKRpUgAAAACkaVIAAAAApGlSAAAAAKRpUgAAAACkaVIAAAAApGlSAAAAAKRpUgAAAACkaVIAAAAApGlSAAAAAKRpUgAAAACkaVIAAAAApGlSAADAspg7v1BKuebqzV1sW21VjQBAX9KkAOgx42Obqh9aCy2zAVBb7Xa73WqXUq6/dqyLzaut2q12u902mQC1tXhMvniU/v+nSQHQY5rNgd07t5VSLsxpUgA1PkuZv1j9MLppbRebL261OA4ANVQdk+/eua3ZXHJi0qQAWEbVPRcb1o1c3mE/+YmdpZSJk1OdTsckA9TTxLuTpZS77ryl6xGqbatxAKihTqczcXJq8fh8qWrRpMZG1xeXuwH6zuJdG7uuu+ryjvzgH3y6+uKYOjNjngFqaHpitros8Rd/eEfXg1Tbzp1fmJ6YNaUANTR1ZqaKOdXx+VLVoknd9ts7Synzsxd8nAD9ZPFuix3jWy7vyDvGtzz96H2llIkTk05UAOpmdnLu9LFzpZT99+y98Ybxrse58Ybx/ffsLaWcPnZudnLOxALUyvTE7MSJyVLK04/e190Bf6MOdz0cfOblL3zpOwPNgfGPbW00Gj5XgP5w9ufvTZ2Z+dStuw59/0+XY/y9d3/r+af/zDwD9ITuzjtarfa2PV8+eeq9UsrIhuFNV60bbA6aTIAra2H2wsS7k9V62Es52q9Fkzp1dmrrzftLKWs3j2y6er1PF6APzE7O/eKdiVLKc9978DO37V6Ot2i12itWODMB6A1dn3e0Wu2vfOOHB546tPhfRjYMrxwZGhz0bFyAqAsLrfnphSpFVfbfs/fbX/18F083rzRq8nTYaqlUKWXrjo2r1g37pAF6Wmuh9e7RM+1W+647bzn42P3L90bV6tqx33qguoQOwBU3Nrr+yYfv/dWrEdW+urvzDndRAPSKLvbzjfr8xqK9d3/r+Z++UUoZ2TC8eXz9wIDrHgA9+VU0dWamurF8bHT90RcfXj2ycvnebvE8Z3pm/u1jpw4fOf7sT17zKQDk7bn5upt2bb/+2rHRTWv/r3111/t5AHriRGDJO/n6NKkPLModXjO0cvXQiqGmzxWgJ1y82J6fWZg59/4zaHfv3PbMd/df9qebX8bzHAAyLr1J2c8D9OV+vhZNytUPgP62fN81zlUA+vhcxX4eoL/38+6PAwAAACCtRnfGufoB0H+shAUAAH4t66QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABIa5oCAAAA+kCj0TAJl1en0zEJLB9NCgAAgH4goEBvce8eAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaZoUAAAAAGmaFAAAAABpmhQAAAAAaU1TAAAAQB9oNBom4fLqdDomgeWjSQEAANAPBBToLe7dAwAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIE2TAgAAACBNkwIAAAAgTZMCAAAAIK1pCgDodY1GwyQAAEBvqVGTckYBAAAA8CFhnRQAPazT6ZgEgL7n6jVAX6pFk3JGAQAAAPCh0tCDAAAAAAjze/cAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABI06QAAAAASNOkAAAAAEjTpAAAAABIW2xS997+VKPRaDQe+pPBW2//XKPxzPl/+4+Zr//364du+t09t3+u0Vjuf1CzcWnvcaZZbT/x/p/vNbsfb/MS/y13/Jq//8XG8s8Z/9t807wDAABAjf0Xm+2nbkjFZhQAAAAASUVORK5CYII=" />
                <div class="c x0 y1 w2 h0">
                    <div class="t m0 x1 h2 y2 ff1 fs0 fc0 sc0 ls2 ws3"><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x1 h2 y3 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y4 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y5 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y6 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y7 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y8 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y9 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 ya ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 yb ff1 fs0 fc0 sc0 ls2 ws3"><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x1 h2 yc ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 yd ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 ye ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 yf ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y10 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y11 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y12 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y13 ff1 fs0 fc0 sc0 ls2 ws3"><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x1 h2 y14 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y15 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y16 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y17 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y2 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y3 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y4 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y5 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y6 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y7 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y8 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y9 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 ya ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 yb ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 yc ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 yd ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 ye ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 yf ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y10 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y11 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y12 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y13 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y14 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y15 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y16 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x2 h2 y17 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y2 ff1 fs0 fc0 sc0 ls2 ws3"><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x4 h2 y3 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y4 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y5 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y6 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y7 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y8 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y9 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 ya ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 yb ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 yc ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 yd ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 ye ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 yf ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y10 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y11 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y12 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y13 ff1 fs0 fc0 sc0 ls2 ws3"><span class="fc3 sc0"> </span></div>
                    <div class="t m0 x4 h2 y14 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y15 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x4 h2 y16 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x1 h2 y18 ff1 fs0 fc0 sc0 ls2 ws3"> </div>
                </div>
                <div class="c x12 ya0 w4 h6">
                    <div class="t m0 x15 h7 y2c ff5 fs1 fc1 sc0 ls2 ws3">SABBATH SCHOOL<span class="_ _0"></span>
                        09:00H<span class="_ _0"></span>RS TO 10:30HRS </div>
                </div>
                <div class="c x12 ya1 w4 h6">
                    <div class="t m0 x16 h7 y2c ff5 fs1 fc1 sc0 ls2 ws3">MAIN SERVICE 1<span class="_ _0"></span>1:00HRS
                        TO 12:00HRS<span class="_ _0"></span> </div>
                </div>
                <div class="c x12 ya2 w4 h6">
                    <div class="t m0 xc h7 y2c ff5 fs1 fc1 sc0 ls2 ws3">AFTERNOON PROGRAMM<span class="_ _7"></span>E:
                        1<span class="_ _5"></span>5:30 TO 17:<span class="_ _0"></span>00HRS </div>
                </div>
                <div class="c x1 ya3 wd h14">
                    <div class="t m0 x8 hc ya4 ff7 fs1 fc0 sc0 ls2 ws3">PIANO: <span class="_ _12"></span> <span
                            class="_ _2"> </span> <span class="_ _2"> </span>BR. MUBITA JOHN<span class="_ _0"></span>
                    </div>
                    <div class="t m0 x8 hc ya5 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span><span class="ls6 ws4">BBB</span> </div>
                    <div class="t m0 x8 hc ya6 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span><span class="ls7 ws5">NNN</span> </div>
                    <div class="t m0 x8 hc ya7 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _15"> </span>JJJKKJ </div>
                    <div class="t m0 x8 hc ya8 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>NMBNMJN </div>
                    <div class="t m0 x8 hc ya9 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span><span class="ls6 ws4">BBB</span> </div>
                    <div class="t m0 x8 hc yaa ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span><span class="ls6 ws4">BBB</span> </div>
                    <div class="t m0 x8 hc yab ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc yac ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>BFDFGHF </div>
                    <div class="t m0 x8 hc yad ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                    <div class="t m0 x8 hc yae ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGGNHHH </div>
                    <div class="t m0 x8 hc yaf ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGGNHHH </div>
                </div>
                <div class="c x1 yb0 wd h15">
                    <div class="t m0 x8 hc yb1 ff7 fs1 fc0 sc0 ls2 ws3">PIANO: <span class="_ _12"></span> <span
                            class="_ _2"> </span> <span class="_ _2"> </span>BR. MUBITA JOHN<span class="_ _0"></span>
                    </div>
                    <div class="t m0 x8 hc yb2 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span><span class="ls6 ws4">BBB</span> </div>
                    <div class="t m0 x8 hc yb3 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span><span class="ls7 ws5">NNN</span> </div>
                    <div class="t m0 x8 hc yb4 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _15"> </span>JJJKKJ </div>
                    <div class="t m0 x8 hc yb5 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>NMBNMJN </div>
                    <div class="t m0 x8 hc yb6 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc yb7 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                    <div class="t m0 x8 hc yb8 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGGNHHH </div>
                    <div class="t m0 x8 hc yb9 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc yba ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                    <div class="t m0 x8 hc ybb ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc ybc ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                </div>
                <div class="c x1 ybd wd h16">
                    <div class="t m0 x8 hc ybe ff7 fs1 fc0 sc0 ls2 ws3">PIANO: <span class="_ _12"></span> <span
                            class="_ _2"> </span> <span class="_ _2"> </span>BR. MUBITA JOHN<span class="_ _0"></span>
                    </div>
                    <div class="t m0 x8 hc ybf ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span><span class="ls6 ws4">BBB</span> </div>
                    <div class="t m0 x8 hc yc0 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span><span class="ls7 ws5">NNN</span> </div>
                    <div class="t m0 x8 hc yc1 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _15"> </span>JJJKKJ </div>
                    <div class="t m0 x8 hc yc2 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>NMBNMJN </div>
                    <div class="t m0 x8 hc yc3 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc yc4 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                    <div class="t m0 x8 hc yc5 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGGNHHH </div>
                    <div class="t m0 x8 hc yc6 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc yc7 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                    <div class="t m0 x8 hc yc8 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc yc9 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                </div>
                <div class="c x17 yca w7 h6">
                    <div class="t m0 x18 h7 y2c ff5 fs1 fc1 sc0 ls2 ws3">GENERAL ANNOU<span class="_ _0"></span>NCEMENTS
                    </div>
                </div>
                <div class="c x19 ycb we h17">
                    <div class="t m0 x8 hc ycc ff7 fs1 fc0 sc0 ls2 ws3">There weren&apos;t sup<span
                            class="_ _0"></span>posed to be drag<span class="_ _0"></span>ons flying in </div>
                    <div class="t m0 x8 hc ycd ff7 fs1 fc0 sc0 ls2 ws3">the sky. First and<span class="_ _0"></span>
                        foremost,<span class="_ _0"></span> dragons didn&apos;t exi<span class="_ _0"></span>st. </div>
                    <div class="t m0 x8 hc yce ff7 fs1 fc0 sc0 ls2 ws3">They were mythic<span class="_ _0"></span>al
                        creatur<span class="_ _0"></span>es from fantas<span class="_ _0"></span>y books </div>
                    <div class="t m0 x8 hc ycf ff7 fs1 fc0 sc0 ls2 ws3">like unicorns. This <span
                            class="_ _0"></span>was somethin<span class="_ _0"></span>g that Pete <span
                            class="_ _0"></span>knew </div>
                    <div class="t m0 x8 hc yd0 ff7 fs1 fc0 sc0 ls2 ws3">in his heart to be true<span
                            class="_ _0"></span> so he was<span class="_ _0"></span> having a difficul<span
                            class="_ _0"></span>t </div>
                    <div class="t m0 x8 hc yd1 ff7 fs1 fc0 sc0 ls2 ws3">time acknowledg<span class="_ _0"></span>ing
                        that there <span class="_ _0"></span>were actually fire-</div>
                    <div class="t m0 x8 hc yd2 ff7 fs1 fc0 sc0 ls2 ws3">breathing dragons fl<span
                            class="_ _0"></span>ying in the sk<span class="_ _0"></span>y above him.h<span
                            class="_ _0"></span>ere </div>
                    <div class="t m0 x8 hc yd3 ff7 fs1 fc0 sc0 ls2 ws3">weren&apos;t supposed <span
                            class="_ _0"></span>to be dragons flying<span class="_ _0"></span> in the sky. </div>
                    <div class="t m0 x8 hc yd4 ff7 fs1 fc0 sc0 ls2 ws3">First and fore<span class="_ _0"></span>most,
                        dragons did<span class="_ _0"></span>n&apos;t exist. They were </div>
                    <div class="t m0 x8 hc yd5 ff7 fs1 fc0 sc0 ls2 ws3">mythical creatures<span class="_ _0"></span>
                        from fa<span class="_ _0"></span>ntasy books like </div>
                    <div class="t m0 x8 hc yd6 ff7 fs1 fc0 sc0 ls2 ws3">unicorns. This was . <span
                            class="_ _0"></span>This was something<span class="_ _0"></span> that Pete </div>
                    <div class="t m0 x8 hc yd7 ff7 fs1 fc0 sc0 ls2 ws3">knew in his heart to<span class="_ _0"></span>
                        be true so he was ha<span class="_ _0"></span>ving a </div>
                    <div class="t m0 x8 hc yd8 ff7 fs1 fc0 sc0 ls2 ws3">difficult time ackno<span
                            class="_ _0"></span>wledgin<span class="_ _0"></span>g that there were<span
                            class="_ _0"></span> </div>
                    <div class="t m0 x8 hc yd9 ff7 fs1 fc0 sc0 ls2 ws3">actually fire-breathin<span
                            class="_ _0"></span>g dragons flying<span class="_ _0"></span> in the sky </div>
                    <div class="t m0 x8 hc yda ff7 fs1 fc0 sc0 ls2 ws3">above him.here <span
                            class="_ _0"></span>weren&apos;t su<span class="_ _0"></span>pposed to be dragons </div>
                    <div class="t m0 x8 hc ydb ff7 fs1 fc0 sc0 ls2 ws3">flying in the sky. Firs<span
                            class="_ _0"></span>t and forem<span class="_ _0"></span>ost, dragons didn&apos;t </div>
                    <div class="t m0 x8 hc ydc ff7 fs1 fc0 sc0 ls2 ws3">exist. They were <span
                            class="_ _0"></span>mythical creatures <span class="_ _0"></span>from fantasy<span
                            class="_ _0"></span> </div>
                    <div class="t m0 x8 hc ydd ff7 fs1 fc0 sc0 ls2 ws3">books like unicorns. <span
                            class="_ _0"></span>This was somethin<span class="_ _0"></span>g that Pete </div>
                    <div class="t m0 x8 hc yde ff7 fs1 fc0 sc0 ls2 ws3">knew in his heart to<span class="_ _0"></span>
                        be true so he was ha<span class="_ _0"></span>ving a </div>
                    <div class="t m0 x8 hc ydf ff7 fs1 fc0 sc0 ls2 ws3">difficult time ackno<span
                            class="_ _0"></span>wledgin<span class="_ _0"></span>g that dragons did<span
                            class="_ _0"></span>n&apos;t </div>
                    <div class="t m0 x8 hc ye0 ff7 fs1 fc0 sc0 ls2 ws3">exist. They were <span
                            class="_ _0"></span>mythical creatures <span class="_ _0"></span>from fantasy </div>
                    <div class="t m0 x8 hc ye1 ff7 fs1 fc0 sc0 ls2 ws3">books like unicorns. <span
                            class="_ _0"></span>This was somethin<span class="_ _0"></span>g that Pete </div>
                    <div class="t m0 x8 hc ye2 ff7 fs1 fc0 sc0 ls2 ws3">knew in his heart to<span class="_ _0"></span>
                        be true so he was ha<span class="_ _0"></span>ving a </div>
                    <div class="t m0 x8 hc ye3 ff7 fs1 fc0 sc0 ls2 ws3">difficult time ackno<span
                            class="_ _0"></span>wledgin<span class="_ _0"></span>g that there were<span
                            class="_ _0"></span> </div>
                    <div class="t m0 x8 hc ye4 ff7 fs1 fc0 sc0 ls2 ws3">actually fire-breathin<span
                            class="_ _0"></span>g dragons flying<span class="_ _0"></span> in the sky </div>
                    <div class="t m0 x8 hc ye5 ff7 fs1 fc0 sc0 ls2 ws3">above him. </div>
                </div>
                <div class="c x1a ye6 w7 h18">
                    <div class="t m0 x1b h7 ye7 ff5 fs1 fc1 sc0 ls2 ws3">CARES AND CON<span class="_ _0"></span>CERNS
                    </div>
                </div>
                <div class="c x1a ye8 wf h19">
                    <div class="t m0 x8 hc ye9 ff7 fs1 fc0 sc0 ls2 ws3">PIANO: <span class="_ _12"></span> <span
                            class="_ _2"> </span> <span class="_ _2"> </span>BR. MUBITA JOHN<span class="_ _0"></span>
                    </div>
                    <div class="t m0 x8 hc yb2 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span><span class="ls6 ws4">BBB</span> </div>
                    <div class="t m0 x8 hc yb3 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span><span class="ls7 ws5">NNN</span> </div>
                    <div class="t m0 x8 hc yb4 ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _15"> </span>JJJKKJ </div>
                    <div class="t m0 x8 hc yb5 ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>NMBNMJN </div>
                    <div class="t m0 x8 hc yea ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc yeb ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                    <div class="t m0 x8 hc yec ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGGNHHH </div>
                    <div class="t m0 x8 hc yed ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc yee ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                    <div class="t m0 x8 hc yef ff7 fs1 fc0 sc0 ls2 ws3">CHORISTER: <span class="_ _13"> </span> <span
                            class="_ _2"> </span>BBNJJY </div>
                    <div class="t m0 x8 hc ybc ff7 fs1 fc0 sc0 ls2 ws3">OPENING PRAYER:<span class="_ _0"></span> <span
                            class="_ _14"> </span>GHGHGH </div>
                </div>
                <div class="c x1c yf0 w9 h6">
                    <div class="t m0 x1d h7 y2c ffc fs1 fc1 sc0 ls2 ws3">PASTORS’ CORNE<span class="_ _0"></span>R<span
                            class="ff5"> </span></div>
                </div>
                <div class="c x1c yf1 w10 h1a">
                    <div class="t m0 x8 h1b yf2 ffd fs1 fc0 sc0 ls2 ws3">The Hebrew word f<span class="_ _0"></span>rom
                        which<span class="_ _0"></span> the word &apos;fool&apos; was </div>
                    <div class="t m0 x8 h1b yf3 ffd fs1 fc0 sc0 ls2 ws3">translated denotes one<span
                            class="_ _0"></span> who is mo<span class="_ _0"></span>rally deficient.<span
                            class="_ _0"></span> </div>
                    <div class="t m0 x8 h1b yf4 ffd fs1 fc0 sc0 ls2 ws3">That moral deficien<span class="_ _0"></span>cy
                        is exhib<span class="_ _0"></span>ited in killing other<span class="_ _0"></span> </div>
                    <div class="t m0 x8 h1b yf5 ffd fs1 fc0 sc0 ls2 ws3">people, frustrating <span
                            class="_ _0"></span>the plans of the poo<span class="_ _0"></span>r, stealing, </div>
                    <div class="t m0 x8 h1b y71 ffd fs1 fc0 sc0 ls2 ws3">sexual immorality,<span class="_ _0"></span>
                        abortions and many othe<span class="_ _0"></span>r evils. </div>
                    <div class="t m0 x8 h1b yf6 ffd fs1 fc0 sc0 ls2 ws3">They do these things b<span
                            class="_ _0"></span>ecause they<span class="_ _0"></span> do not feel the<span
                            class="_ _0"></span> </div>
                    <div class="t m0 x8 h1b yf7 ffd fs1 fc0 sc0 ls2 ws3">sense of accountability fo<span
                            class="_ _0"></span>r their de<span class="_ _0"></span>eds. They </div>
                    <div class="t m0 x8 h1b yf8 ffd fs1 fc0 sc0 ls2 ws3">reason that they can hid<span
                            class="_ _0"></span>e from God as <span class="_ _0"></span>they do </div>
                    <div class="t m0 x8 h1b yf9 ffd fs1 fc0 sc0 ls2 ws3">from men. </div>
                    <div class="t m0 x8 h1b yfa ffd fs1 fc0 sc0 ls2 ws3">Refusing the exist<span
                            class="_ _0"></span>ence of God is not only<span class="_ _0"></span> verbal </div>
                    <div class="t m0 x8 h1b yfb ffd fs1 fc0 sc0 ls2 ws3">pronouncements bu<span class="_ _0"></span>t
                        also a defiant lifestyl<span class="_ _0"></span>e. When </div>
                    <div class="t m0 x8 h1b yfc ffd fs1 fc0 sc0 ls2 ws3">one fails to submit <span
                            class="_ _0"></span>to the Lordship of Yah<span class="_ _0"></span>weh and </div>
                    <div class="t m0 x8 h1b yfd ffd fs1 fc0 sc0 ls2 ws3">thinks that they can<span class="_ _0"></span>
                        live better<span class="_ _0"></span> and meaning<span class="_ _0"></span>ful </div>
                    <div class="t m0 x8 h1b yfe ffd fs1 fc0 sc0 ls2 ws3">lives outside the p<span
                            class="_ _0"></span>rinciples a<span class="_ _0"></span>nd laws of God, they </div>
                    <div class="t m0 x8 h1b yff ffd fs1 fc0 sc0 ls2 ws3">are denying His exist<span
                            class="_ _0"></span>ence. There <span class="_ _0"></span> are many people<span
                            class="_ _0"></span> </div>
                    <div class="t m0 x8 h1b y100 ffd fs1 fc0 sc0 ls2 ws3">who claim to love God<span
                            class="_ _0"></span> but teac<span class="_ _0"></span>h others that it is </div>
                    <div class="t m0 x8 h1b y101 ffd fs1 fc0 sc0 ls2 ws3">not necessary to obey<span
                            class="_ _0"></span> the co<span class="_ _0"></span>mmandments of God </div>
                    <div class="t m0 x8 h1b y102 ffd fs1 fc0 sc0 ls2 ws3">today. That kind of <span
                            class="_ _0"></span>teaching is a rebelli<span class="_ _0"></span>on against </div>
                    <div class="t m0 x8 h1b y103 ffd fs1 fc0 sc0 ls2 ws3">God&apos;s government. And<span
                            class="_ _0"></span> that is tanta<span class="_ _0"></span>mount to </div>
                    <div class="t m0 x8 h1b y104 ffd fs1 fc0 sc0 ls2 ws3">refusing the exis<span
                            class="_ _0"></span>tence of th<span class="_ _0"></span>e God. There cannot be </div>
                    <div class="t m0 x8 h1b y105 ffd fs1 fc0 sc0 ls2 ws3">morality in disobeyin<span
                            class="_ _0"></span>g God. Ob<span class="_ _0"></span>eying God is </div>
                    <div class="t m0 x8 h1b y106 ffd fs1 fc0 sc0 ls2 ws3">recognizing tha<span class="_ _0"></span>t we
                        cannot live wi<span class="_ _0"></span>thout Him. </div>
                    <div class="t m0 x8 h1b y107 ffd fs1 fc0 sc0 ls2 ws3">&quot;Those who obey Hi<span
                            class="_ _0"></span>s commands live in H<span class="_ _0"></span>im, and </div>
                    <div class="t m0 x8 h1b y108 ffd fs1 fc0 sc0 ls2 ws3">He in them. And this is<span
                            class="_ _0"></span> how we kno<span class="_ _0"></span>w that He lives </div>
                    <div class="t m0 x8 h1b y109 ffd fs1 fc0 sc0 ls2 ws3">in us. We know it by the<span
                            class="_ _0"></span> Spirit He gav<span class="_ _0"></span>e us.&quot; (1 John </div>
                    <div class="t m0 x8 h1b y10a ffd fs1 fc0 sc0 ls2 ws3">3:24). </div>
                </div>
                <div class="c x1e ye6 w11 h18">
                    <div class="t m0 x1f h7 ye7 ff5 fs1 fc1 sc0 ls2 ws3">ON DUTY </div>
                </div>
                <div class="c x1e y10b wa h1c">
                    <div class="t m0 x20 h1d y10c ffe fs1 fc0 sc0 ls2 ws3">24 OCT 2022<span class="_ _0"></span> </div>
                    <div class="t m0 x8 h7 y10d ff7 fs1 fc0 sc0 ls2 ws3">1. <span class="ff5 ws6">ELDERS</span>: BR.
                        MUBITA JO<span class="_ _0"></span>HN &amp; MUBITA JOH<span class="_ _0"></span>N </div>
                    <div class="t m0 x8 h7 y10e ff7 fs1 fc0 sc0 ls2 ws3">2. <span class="ff5 ws6">CLERKS</span>: BR.
                        MUBITA JO<span class="_ _0"></span>HN &amp; MUBITA JOH<span class="_ _0"></span>N </div>
                    <div class="t m0 x8 h7 y10f ff7 fs1 fc0 sc0 ls2 ws3">3. <span class="ff5 ws6">DEACONS</span>: BR.
                        MU<span class="_ _0"></span>BITA JOHN<span class="_ _0"></span> &amp; MUBITA JOHN </div>
                    <div class="t m0 x8 hc yb5 ff7 fs1 fc0 sc0 ls2 ws3"> </div>
                    <div class="t m0 x20 h1d yb6 ffe fs1 fc0 sc0 ls2 ws3">24 OCT 2022<span class="_ _0"></span> </div>
                    <div class="t m0 x8 h7 y110 ff7 fs1 fc0 sc0 ls2 ws3">1. <span class="ff5 ws6">ELDERS</span>: BR.
                        MUBITA JO<span class="_ _0"></span>HN &amp; MUBITA JOH<span class="_ _0"></span>N </div>
                    <div class="t m0 x8 h7 y111 ff7 fs1 fc0 sc0 ls2 ws3">2. <span class="ff5 ws6">CLERKS</span>: BR.
                        MUBITA JO<span class="_ _0"></span>HN &amp; MUBITA JOH<span class="_ _0"></span>N </div>
                    <div class="t m0 x8 h7 y112 ff7 fs1 fc0 sc0 ls2 ws3">3. <span class="ff5 ws6">DEACONS</span>: BR.
                        MU<span class="_ _0"></span>BITA JOHN<span class="_ _0"></span> &amp; MUBITA JOHN </div>
                </div>
            </div>
            <div class="pi" data-data='{"ctm":[1.000000,0.000000,0.000000,1.000000,0.000000,0.000000]}'></div>
        </div>
    </div>
<button id="create_pdf">pdffff</button>
</body>

</html>